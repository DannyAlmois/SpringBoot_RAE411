package com.example.sbsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
